- How to set up:

1. Create the database. That can be done by executing the create_database.sql file in Microsoft SQL Server Management Studio. 

2. Run "LoginAuth.exe".

3. Log in. Email - "user@user.com" , Password - "password" .
