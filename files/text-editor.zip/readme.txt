How to set up:

1. Create a MySQL instance with username "root" and password "root".
2. Create the database from the "Create-DB-MYSQL.sql" file.
3. Start the application (text-editor.exe).
4. Log in. Username = "admin". Password = "password".