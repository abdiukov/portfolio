﻿The calculated tax files are stored here. 
To see how the tax is calculated, please read "HowTaxIsCalculated.docx"