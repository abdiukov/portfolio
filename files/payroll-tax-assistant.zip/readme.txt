- How to set up:

1. (Optional) Change the input csv file. The file is located at application\Import\employee-payroll-data.csv .

2. Start the application ("UI.exe").